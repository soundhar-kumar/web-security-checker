# Web Security Checker Backend

A comprehensive Python backend for the Web Security Checker application, built with FastAPI and designed for educational purposes.

## Features

- **Real HTTP Security Analysis**: Performs actual HTTP requests to analyze websites
- **Comprehensive Security Checks**:
  - HTTPS/SSL Certificate validation
  - Security headers analysis
  - Cookie security assessment
  - Form security evaluation
  - External link analysis
- **Educational Focus**: Detailed explanations and recommendations for each security check
- **RESTful API**: Clean, documented API endpoints
- **Error Handling**: Robust error handling and validation

## Installation

1. **Navigate to backend directory**:
   ```bash
   cd backend
   ```

2. **Install Python dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

## Running the Server

### Option 1: Using the run script
```bash
python run.py
```

### Option 2: Using uvicorn directly
```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

The server will start on `http://localhost:8000`

## API Endpoints

### GET /
- **Description**: API information and available endpoints
- **Response**: JSON with API details

### GET /health
- **Description**: Health check endpoint
- **Response**: Server status and timestamp

### POST /scan
- **Description**: Perform comprehensive security scan
- **Request Body**:
  ```json
  {
    "url": "https://example.com"
  }
  ```
- **Response**: Detailed security analysis results

## API Documentation

Once the server is running, visit:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## Security Checks Performed

### 1. HTTPS Encryption Check
- Verifies if the website uses HTTPS
- Checks for proper redirects
- Analyzes encryption status

### 2. Security Headers Analysis
- Content-Security-Policy
- X-Frame-Options
- X-Content-Type-Options
- X-XSS-Protection
- Strict-Transport-Security
- Referrer-Policy
- Permissions-Policy

### 3. Cookie Security Assessment
- Secure flag presence
- HttpOnly attribute
- SameSite configuration
- Overall cookie security score

### 4. Form Security Evaluation
- HTTPS form submission
- CSRF protection detection
- Form method analysis

### 5. External Links Analysis
- External link counting
- Security attribute checking (noopener, nofollow)
- Risk assessment based on link count

### 6. SSL Certificate Validation
- Certificate validity
- Expiration date checking
- Issuer information
- Certificate configuration

## Example Response

```json
{
  "url": "https://example.com",
  "scanned_at": "2024-01-15T10:30:00",
  "https_check": {
    "title": "HTTPS Encryption",
    "description": "Checks if the website uses secure HTTPS protocol",
    "status": "pass",
    "explanation": "This website uses HTTPS...",
    "recommendation": "Excellent! Continue using HTTPS...",
    "details": ["✓ Encrypted data transmission", "✓ Identity verification"]
  },
  // ... other security checks
}
```

## Development

### Project Structure
```
backend/
├── main.py              # FastAPI application and security scanner
├── run.py               # Server startup script
├── requirements.txt     # Python dependencies
└── README.md           # This file
```

### Adding New Security Checks

1. Add a new method to the `SecurityScanner` class
2. Update the `scan_website` method to include the new check
3. Update the `SecurityResult` model if needed

### Error Handling

The API includes comprehensive error handling:
- Request validation errors
- Network timeout errors
- SSL certificate errors
- HTML parsing errors

## Educational Value

This backend demonstrates:
- **Web Security Concepts**: Real-world security analysis
- **Python Programming**: Clean, well-documented code
- **API Development**: RESTful API design with FastAPI
- **Error Handling**: Robust error management
- **Documentation**: Comprehensive API documentation

## Portfolio Benefits

- Shows practical Python development skills
- Demonstrates understanding of web security
- Clean, professional code structure
- Real-world application with educational value
- Comprehensive testing and error handling

## Dependencies

- **FastAPI**: Modern, fast web framework
- **Requests**: HTTP library for making requests
- **BeautifulSoup4**: HTML parsing and analysis
- **Uvicorn**: ASGI server for running FastAPI
- **Pydantic**: Data validation and settings management

## Security Considerations

- The scanner respects robots.txt (when implemented)
- Implements request timeouts and retry logic
- Uses proper User-Agent headers
- Handles SSL certificate validation
- Includes rate limiting considerations

## Future Enhancements

- Database integration for scan history
- User authentication and API keys
- Advanced security checks (OWASP Top 10)
- Scheduled scanning capabilities
- Email notifications for security issues