from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, HttpUrl
from typing import List, Optional, Dict, Any
import requests
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
import re
from datetime import datetime
import ssl
import socket
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

app = FastAPI(
    title="Web Security Checker API",
    description="A comprehensive web security analysis tool for educational purposes",
    version="1.0.0"
)

# CORS middleware to allow frontend connections
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class SecurityCheckRequest(BaseModel):
    url: HttpUrl

class SecurityCheck(BaseModel):
    title: str
    description: str
    status: str  # 'pass', 'warning', 'fail'
    explanation: str
    recommendation: Optional[str] = None
    details: Optional[List[str]] = None

class SecurityResult(BaseModel):
    url: str
    scanned_at: str
    https_check: SecurityCheck
    headers_check: SecurityCheck
    cookie_check: SecurityCheck
    form_check: SecurityCheck
    link_check: SecurityCheck
    ssl_check: SecurityCheck

class SecurityScanner:
    def __init__(self):
        self.session = requests.Session()
        # Configure retry strategy
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        
        # Set headers to mimic a real browser
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
        })

    def scan_website(self, url: str) -> SecurityResult:
        """Perform comprehensive security scan of a website"""
        try:
            # Make initial request
            response = self.session.get(url, timeout=10, allow_redirects=True)
            
            return SecurityResult(
                url=url,
                scanned_at=datetime.now().isoformat(),
                https_check=self._check_https(url, response),
                headers_check=self._check_security_headers(response),
                cookie_check=self._check_cookie_security(response),
                form_check=self._check_form_security(response, url),
                link_check=self._check_external_links(response, url),
                ssl_check=self._check_ssl_certificate(url)
            )
        except requests.exceptions.RequestException as e:
            raise HTTPException(status_code=400, detail=f"Failed to scan website: {str(e)}")

    def _check_https(self, url: str, response: requests.Response) -> SecurityCheck:
        """Check if website uses HTTPS"""
        is_https = url.startswith('https://')
        final_url_https = response.url.startswith('https://')
        
        if is_https and final_url_https:
            return SecurityCheck(
                title="HTTPS Encryption",
                description="Checks if the website uses secure HTTPS protocol",
                status="pass",
                explanation="This website uses HTTPS, which encrypts data between your browser and the server, protecting against eavesdropping and tampering.",
                recommendation="Excellent! Continue using HTTPS for all pages and resources.",
                details=[
                    "✓ Initial request uses HTTPS",
                    "✓ Final URL uses HTTPS",
                    "✓ Encrypted data transmission",
                    "✓ Identity verification enabled"
                ]
            )
        elif not is_https but final_url_https:
            return SecurityCheck(
                title="HTTPS Encryption",
                description="Checks if the website uses secure HTTPS protocol",
                status="warning",
                explanation="Website redirects to HTTPS but initial request was HTTP. This could expose users to attacks during the redirect.",
                recommendation="Configure automatic HTTPS redirects and consider HSTS headers.",
                details=[
                    "⚠ Initial request uses HTTP",
                    "✓ Redirects to HTTPS",
                    "⚠ Brief exposure during redirect"
                ]
            )
        else:
            return SecurityCheck(
                title="HTTPS Encryption",
                description="Checks if the website uses secure HTTPS protocol",
                status="fail",
                explanation="This website uses HTTP instead of HTTPS, meaning data is transmitted in plain text and vulnerable to interception.",
                recommendation="Upgrade to HTTPS immediately. Obtain an SSL certificate and configure your server to use HTTPS.",
                details=[
                    "✗ Uses HTTP instead of HTTPS",
                    "✗ Data transmitted in plain text",
                    "✗ Vulnerable to man-in-the-middle attacks",
                    "✗ Browsers show 'Not Secure' warning"
                ]
            )

    def _check_security_headers(self, response: requests.Response) -> SecurityCheck:
        """Analyze security headers"""
        headers = response.headers
        security_headers = {
            'Content-Security-Policy': 'Prevents XSS attacks by controlling resource loading',
            'X-Frame-Options': 'Prevents clickjacking attacks',
            'X-Content-Type-Options': 'Prevents MIME type sniffing attacks',
            'X-XSS-Protection': 'Enables browser XSS filtering',
            'Strict-Transport-Security': 'Enforces HTTPS connections',
            'Referrer-Policy': 'Controls referrer information sent',
            'Permissions-Policy': 'Controls browser feature access'
        }
        
        found_headers = []
        missing_headers = []
        
        for header, description in security_headers.items():
            if header.lower() in [h.lower() for h in headers.keys()]:
                found_headers.append(f"✓ {header}: {description}")
            else:
                missing_headers.append(f"✗ {header}: {description}")
        
        found_count = len(found_headers)
        total_count = len(security_headers)
        
        if found_count >= 5:
            status = "pass"
            explanation = f"Excellent security header implementation! Found {found_count}/{total_count} important security headers."
        elif found_count >= 3:
            status = "warning"
            explanation = f"Good security header coverage with {found_count}/{total_count} headers, but could be improved."
        else:
            status = "fail"
            explanation = f"Poor security header implementation. Only {found_count}/{total_count} important headers found."
        
        return SecurityCheck(
            title="Security Headers",
            description="Analyzes HTTP security headers that protect against common attacks",
            status=status,
            explanation=explanation,
            recommendation="Add missing security headers to protect against XSS, clickjacking, and other attacks.",
            details=found_headers + missing_headers[:3]
        )

    def _check_cookie_security(self, response: requests.Response) -> SecurityCheck:
        """Analyze cookie security attributes"""
        cookies = response.cookies
        
        if not cookies:
            return SecurityCheck(
                title="Cookie Security",
                description="Examines cookie security attributes and configurations",
                status="pass",
                explanation="No cookies detected, so there are no cookie-specific security concerns.",
                recommendation="When implementing cookies, ensure they have Secure, HttpOnly, and SameSite attributes.",
                details=["No cookies found"]
            )
        
        total_cookies = len(cookies)
        secure_cookies = 0
        httponly_cookies = 0
        samesite_cookies = 0
        
        cookie_details = []
        
        for cookie in cookies:
            cookie_info = f"Cookie: {cookie.name}"
            flags = []
            
            if cookie.secure:
                secure_cookies += 1
                flags.append("Secure")
            
            if hasattr(cookie, 'has_nonstandard_attr') and cookie.has_nonstandard_attr('HttpOnly'):
                httponly_cookies += 1
                flags.append("HttpOnly")
            
            if hasattr(cookie, 'has_nonstandard_attr') and cookie.has_nonstandard_attr('SameSite'):
                samesite_cookies += 1
                flags.append("SameSite")
            
            if flags:
                cookie_info += f" ({', '.join(flags)})"
            else:
                cookie_info += " (No security flags)"
            
            cookie_details.append(cookie_info)
        
        security_score = (secure_cookies + httponly_cookies + samesite_cookies) / (total_cookies * 3)
        
        if security_score >= 0.7:
            status = "pass"
            explanation = "Good cookie security implementation with most cookies having appropriate security flags."
        elif security_score >= 0.4:
            status = "warning"
            explanation = "Some cookies have security flags, but improvements are needed."
        else:
            status = "fail"
            explanation = "Poor cookie security. Most cookies lack important security attributes."
        
        return SecurityCheck(
            title="Cookie Security",
            description="Examines cookie security attributes and configurations",
            status=status,
            explanation=explanation,
            recommendation="Add Secure, HttpOnly, and SameSite attributes to all cookies containing sensitive data.",
            details=[
                f"Total cookies: {total_cookies}",
                f"Secure flag: {secure_cookies}/{total_cookies}",
                f"HttpOnly flag: {httponly_cookies}/{total_cookies}",
                f"SameSite attribute: {samesite_cookies}/{total_cookies}"
            ] + cookie_details[:3]
        )

    def _check_form_security(self, response: requests.Response, url: str) -> SecurityCheck:
        """Analyze form security"""
        try:
            soup = BeautifulSoup(response.content, 'html.parser')
            forms = soup.find_all('form')
            
            if not forms:
                return SecurityCheck(
                    title="Form Security",
                    description="Analyzes forms for security best practices",
                    status="pass",
                    explanation="No forms detected on this page, so there are no form-specific security concerns.",
                    recommendation="When adding forms, ensure they submit over HTTPS and include CSRF protection.",
                    details=["No forms found on this page"]
                )
            
            form_count = len(forms)
            https_forms = 0
            csrf_protected = 0
            
            form_details = []
            
            for i, form in enumerate(forms, 1):
                action = form.get('action', '')
                method = form.get('method', 'GET').upper()
                
                # Check if form submits over HTTPS
                if action:
                    form_url = urljoin(url, action)
                    if form_url.startswith('https://'):
                        https_forms += 1
                elif url.startswith('https://'):
                    https_forms += 1
                
                # Check for CSRF tokens (basic detection)
                csrf_inputs = form.find_all('input', {'name': re.compile(r'csrf|token', re.I)})
                if csrf_inputs:
                    csrf_protected += 1
                
                form_details.append(f"Form {i}: {method} method, {'HTTPS' if https_forms >= i else 'HTTP'}")
            
            if https_forms == form_count:
                status = "pass"
                explanation = f"All {form_count} forms submit over HTTPS, providing good basic security."
            elif https_forms > 0:
                status = "warning"
                explanation = f"{https_forms}/{form_count} forms use HTTPS. Some forms may transmit data insecurely."
            else:
                status = "fail"
                explanation = f"None of the {form_count} forms use HTTPS. All form data is transmitted insecurely."
            
            return SecurityCheck(
                title="Form Security",
                description="Analyzes forms for security best practices",
                status=status,
                explanation=explanation,
                recommendation="Ensure all forms submit over HTTPS and implement CSRF protection server-side.",
                details=[
                    f"Total forms found: {form_count}",
                    f"HTTPS forms: {https_forms}/{form_count}",
                    f"Potential CSRF protection: {csrf_protected}/{form_count}"
                ] + form_details[:3]
            )
            
        except Exception as e:
            return SecurityCheck(
                title="Form Security",
                description="Analyzes forms for security best practices",
                status="warning",
                explanation="Could not analyze forms due to parsing error.",
                recommendation="Manually review forms for HTTPS submission and CSRF protection.",
                details=[f"Analysis error: {str(e)}"]
            )

    def _check_external_links(self, response: requests.Response, url: str) -> SecurityCheck:
        """Analyze external links"""
        try:
            soup = BeautifulSoup(response.content, 'html.parser')
            links = soup.find_all('a', href=True)
            
            if not links:
                return SecurityCheck(
                    title="External Links",
                    description="Counts external links and assesses potential security risks",
                    status="pass",
                    explanation="No links found on this page.",
                    recommendation="When adding links, use rel='noopener' for external links opening in new tabs.",
                    details=["No links found"]
                )
            
            parsed_url = urlparse(url)
            domain = parsed_url.netloc
            
            total_links = len(links)
            external_links = 0
            noopener_links = 0
            nofollow_links = 0
            
            for link in links:
                href = link.get('href', '')
                rel = link.get('rel', [])
                
                if isinstance(rel, str):
                    rel = rel.split()
                
                # Check if external link
                if href.startswith('http') and domain not in href:
                    external_links += 1
                    
                    if 'noopener' in rel:
                        noopener_links += 1
                    if 'nofollow' in rel:
                        nofollow_links += 1
            
            if external_links == 0:
                status = "pass"
                explanation = "No external links found, eliminating external link security risks."
            elif external_links <= 5:
                status = "pass"
                explanation = f"Low number of external links ({external_links}). Good for security."
            elif external_links <= 15:
                status = "warning"
                explanation = f"Moderate number of external links ({external_links}). Monitor destinations regularly."
            else:
                status = "fail"
                explanation = f"High number of external links ({external_links}). Increases security risk exposure."
            
            return SecurityCheck(
                title="External Links",
                description="Counts external links and assesses potential security risks",
                status=status,
                explanation=explanation,
                recommendation="Use rel='noopener' and rel='nofollow' attributes for external links. Regularly audit link destinations.",
                details=[
                    f"Total links: {total_links}",
                    f"External links: {external_links}",
                    f"Links with noopener: {noopener_links}",
                    f"Links with nofollow: {nofollow_links}"
                ]
            )
            
        except Exception as e:
            return SecurityCheck(
                title="External Links",
                description="Counts external links and assesses potential security risks",
                status="warning",
                explanation="Could not analyze links due to parsing error.",
                recommendation="Manually review external links for security.",
                details=[f"Analysis error: {str(e)}"]
            )

    def _check_ssl_certificate(self, url: str) -> SecurityCheck:
        """Check SSL certificate details"""
        if not url.startswith('https://'):
            return SecurityCheck(
                title="SSL Certificate",
                description="Analyzes SSL certificate validity and configuration",
                status="fail",
                explanation="Website does not use HTTPS, so no SSL certificate is present.",
                recommendation="Obtain and install an SSL certificate to enable HTTPS.",
                details=["No SSL certificate (HTTP only)"]
            )
        
        try:
            parsed_url = urlparse(url)
            hostname = parsed_url.hostname
            port = parsed_url.port or 443
            
            # Get SSL certificate info
            context = ssl.create_default_context()
            with socket.create_connection((hostname, port), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                    cert = ssock.getpeercert()
            
            # Analyze certificate
            subject = dict(x[0] for x in cert['subject'])
            issuer = dict(x[0] for x in cert['issuer'])
            
            # Check expiration
            not_after = datetime.strptime(cert['notAfter'], '%b %d %H:%M:%S %Y %Z')
            days_until_expiry = (not_after - datetime.now()).days
            
            details = [
                f"Subject: {subject.get('commonName', 'Unknown')}",
                f"Issuer: {issuer.get('organizationName', 'Unknown')}",
                f"Expires in: {days_until_expiry} days",
                f"Version: {cert.get('version', 'Unknown')}"
            ]
            
            if days_until_expiry > 30:
                status = "pass"
                explanation = "SSL certificate is valid and properly configured."
            elif days_until_expiry > 7:
                status = "warning"
                explanation = f"SSL certificate expires soon ({days_until_expiry} days). Plan for renewal."
            else:
                status = "fail"
                explanation = f"SSL certificate expires very soon ({days_until_expiry} days) or has expired."
            
            return SecurityCheck(
                title="SSL Certificate",
                description="Analyzes SSL certificate validity and configuration",
                status=status,
                explanation=explanation,
                recommendation="Ensure SSL certificate is valid and set up automatic renewal.",
                details=details
            )
            
        except Exception as e:
            return SecurityCheck(
                title="SSL Certificate",
                description="Analyzes SSL certificate validity and configuration",
                status="warning",
                explanation="Could not retrieve SSL certificate information.",
                recommendation="Manually verify SSL certificate is properly configured.",
                details=[f"Certificate check error: {str(e)}"]
            )

# Initialize scanner
scanner = SecurityScanner()

@app.get("/")
async def root():
    return {
        "message": "Web Security Checker API",
        "version": "1.0.0",
        "endpoints": {
            "scan": "/scan",
            "health": "/health"
        }
    }

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

@app.post("/scan", response_model=SecurityResult)
async def scan_website(request: SecurityCheckRequest):
    """Perform comprehensive security scan of a website"""
    try:
        url = str(request.url)
        result = scanner.scan_website(url)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Scan failed: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)