import React from 'react';
import SecurityChecker from './components/SecurityChecker';
import './index.css';

function App() {
  return <SecurityChecker />;
}

export default App;