import React, { useState } from 'react';
import { Book, Shield, Lock, Eye, Link, ChevronRight } from 'lucide-react';

const EducationalPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState('https');

  const educationalContent = {
    https: {
      icon: <Lock className="w-6 h-6" />,
      title: 'HTTPS & SSL/TLS',
      content: (
        <div className="space-y-4">
          <p className="text-gray-600">
            HTTPS (HTTP Secure) is the secure version of HTTP. It uses SSL/TLS encryption to protect 
            data transmitted between your browser and the website.
          </p>
          <div className="bg-blue-50 border-l-4 border-blue-400 p-4">
            <h4 className="font-semibold text-blue-800 mb-2">Key Benefits:</h4>
            <ul className="text-blue-700 space-y-1 text-sm">
              <li>• Encrypts data in transit</li>
              <li>• Verifies website identity</li>
              <li>• Prevents man-in-the-middle attacks</li>
              <li>• Required for modern web features</li>
              <li>• Improves SEO rankings</li>
            </ul>
          </div>
          <div className="bg-red-50 border-l-4 border-red-400 p-4">
            <h4 className="font-semibold text-red-800 mb-2">HTTP Risks:</h4>
            <ul className="text-red-700 space-y-1 text-sm">
              <li>• Data transmitted in plain text</li>
              <li>• Vulnerable to eavesdropping</li>
              <li>• No identity verification</li>
              <li>• Browsers show "Not Secure" warnings</li>
            </ul>
          </div>
        </div>
      )
    },
    headers: {
      icon: <Shield className="w-6 h-6" />,
      title: 'Security Headers',
      content: (
        <div className="space-y-4">
          <p className="text-gray-600">
            Security headers are HTTP response headers that help protect your website from common attacks 
            and vulnerabilities.
          </p>
          <div className="grid gap-4">
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <h4 className="font-semibold text-green-800 mb-2">Content-Security-Policy (CSP)</h4>
              <p className="text-green-700 text-sm">Prevents XSS attacks by controlling which resources can be loaded</p>
            </div>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-800 mb-2">X-Frame-Options</h4>
              <p className="text-blue-700 text-sm">Prevents clickjacking by controlling iframe embedding</p>
            </div>
            <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
              <h4 className="font-semibold text-purple-800 mb-2">Strict-Transport-Security</h4>
              <p className="text-purple-700 text-sm">Forces HTTPS connections and prevents downgrade attacks</p>
            </div>
          </div>
        </div>
      )
    },
    cookies: {
      icon: <Eye className="w-6 h-6" />,
      title: 'Cookie Security',
      content: (
        <div className="space-y-4">
          <p className="text-gray-600">
            Cookies store information about your browsing session. Proper security flags help protect 
            this data from malicious access.
          </p>
          <div className="space-y-3">
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <h4 className="font-semibold text-yellow-800 mb-2">Secure Flag</h4>
              <p className="text-yellow-700 text-sm">Ensures cookies are only sent over HTTPS connections</p>
            </div>
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
              <h4 className="font-semibold text-orange-800 mb-2">HttpOnly Flag</h4>
              <p className="text-orange-700 text-sm">Prevents JavaScript access to cookies, reducing XSS risk</p>
            </div>
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <h4 className="font-semibold text-red-800 mb-2">SameSite Attribute</h4>
              <p className="text-red-700 text-sm">Controls when cookies are sent with cross-site requests</p>
            </div>
          </div>
        </div>
      )
    },
    links: {
      icon: <Link className="w-6 h-6" />,
      title: 'External Links',
      content: (
        <div className="space-y-4">
          <p className="text-gray-600">
            External links can pose security risks if not properly managed. Understanding these risks 
            helps maintain website security.
          </p>
          <div className="space-y-4">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <h4 className="font-semibold text-red-800 mb-2">Potential Risks:</h4>
              <ul className="text-red-700 space-y-1 text-sm">
                <li>• Phishing and malware distribution</li>
                <li>• SEO value dilution</li>
                <li>• User trust issues</li>
                <li>• Broken links over time</li>
              </ul>
            </div>
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <h4 className="font-semibold text-green-800 mb-2">Best Practices:</h4>
              <ul className="text-green-700 space-y-1 text-sm">
                <li>• Use rel="noopener" for target="_blank" links</li>
                <li>• Regularly audit external links</li>
                <li>• Consider rel="nofollow" for untrusted content</li>
                <li>• Monitor link destinations</li>
              </ul>
            </div>
          </div>
        </div>
      )
    }
  };

  const tabs = Object.keys(educationalContent);

  return (
    <div className="bg-white rounded-lg shadow-lg">
      <div className="border-b border-gray-200 px-6 py-4">
        <div className="flex items-center mb-4">
          <Book className="w-6 h-6 text-blue-600 mr-3" />
          <h2 className="text-2xl font-bold text-gray-800">Learn Web Security</h2>
        </div>
        <div className="flex space-x-1">
          {tabs.map((tab) => {
            const content = educationalContent[tab as keyof typeof educationalContent];
            return (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                  activeTab === tab
                    ? 'bg-blue-100 text-blue-700 border border-blue-200'
                    : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
                }`}
              >
                {content.icon}
                <span className="ml-2 font-medium">{content.title}</span>
              </button>
            );
          })}
        </div>
      </div>
      
      <div className="p-6">
        {educationalContent[activeTab as keyof typeof educationalContent].content}
      </div>
    </div>
  );
};

export default EducationalPanel;