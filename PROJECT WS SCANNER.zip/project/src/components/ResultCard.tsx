import React, { useState } from 'react';
import { CheckCircle, XCircle, AlertTriangle, ChevronDown, ChevronUp } from 'lucide-react';
import { SecurityCheck } from '../types/security';

interface ResultCardProps {
  check: SecurityCheck;
}

const ResultCard: React.FC<ResultCardProps> = ({ check }) => {
  const [expanded, setExpanded] = useState(false);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pass':
        return <CheckCircle className="w-6 h-6 text-green-600" />;
      case 'warning':
        return <AlertTriangle className="w-6 h-6 text-yellow-600" />;
      case 'fail':
        return <XCircle className="w-6 h-6 text-red-600" />;
      default:
        return <AlertTriangle className="w-6 h-6 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pass':
        return 'border-green-200 bg-green-50';
      case 'warning':
        return 'border-yellow-200 bg-yellow-50';
      case 'fail':
        return 'border-red-200 bg-red-50';
      default:
        return 'border-gray-200 bg-gray-50';
    }
  };

  return (
    <div className={`rounded-lg border-2 p-6 transition-all duration-200 hover:shadow-md ${getStatusColor(check.status)}`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center">
          {getStatusIcon(check.status)}
          <h3 className="text-lg font-semibold text-gray-800 ml-3">{check.title}</h3>
        </div>
      </div>
      
      <p className="text-gray-600 mb-4">{check.description}</p>
      
      <div className="flex items-center justify-between">
        <span className={`px-3 py-1 rounded-full text-sm font-medium ${
          check.status === 'pass' ? 'bg-green-100 text-green-800' :
          check.status === 'warning' ? 'bg-yellow-100 text-yellow-800' :
          'bg-red-100 text-red-800'
        }`}>
          {check.status === 'pass' ? 'Secure' :
           check.status === 'warning' ? 'Needs Attention' :
           'Vulnerable'}
        </span>
        
        <button
          onClick={() => setExpanded(!expanded)}
          className="flex items-center text-blue-600 hover:text-blue-800 transition-colors"
        >
          <span className="text-sm font-medium mr-1">Learn More</span>
          {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>
      
      {expanded && (
        <div className="mt-4 pt-4 border-t border-gray-200 space-y-3">
          <div>
            <h4 className="font-semibold text-gray-800 mb-2">Why This Matters:</h4>
            <p className="text-gray-600 text-sm">{check.explanation}</p>
          </div>
          
          {check.recommendation && (
            <div>
              <h4 className="font-semibold text-gray-800 mb-2">Recommendation:</h4>
              <p className="text-gray-600 text-sm">{check.recommendation}</p>
            </div>
          )}
          
          {check.details && check.details.length > 0 && (
            <div>
              <h4 className="font-semibold text-gray-800 mb-2">Details:</h4>
              <ul className="text-gray-600 text-sm space-y-1">
                {check.details.map((detail, index) => (
                  <li key={index}>• {detail}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ResultCard;