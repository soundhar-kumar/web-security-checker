import React, { useState } from 'react';
import { Shield, AlertTriangle, CheckCircle, XCircle, Info, Loader } from 'lucide-react';
import { SecurityResult, SecurityCheck } from '../types/security';
import { performSecurityChecks } from '../utils/securityUtils';
import ResultCard from './ResultCard';
import EducationalPanel from './EducationalPanel';

const SecurityChecker: React.FC = () => {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<SecurityResult | null>(null);
  const [error, setError] = useState('');
  const [progress, setProgress] = useState(0);

  const validateUrl = (inputUrl: string): boolean => {
    try {
      const urlPattern = /^https?:\/\/[^\s/$.?#].[^\s]*$/i;
      return urlPattern.test(inputUrl);
    } catch {
      return false;
    }
  };

  const handleScan = async () => {
    if (!url.trim()) {
      setError('Please enter a URL to scan');
      return;
    }

    if (!validateUrl(url)) {
      setError('Please enter a valid URL (must start with http:// or https://)');
      return;
    }

    setError('');
    setLoading(true);
    setProgress(0);
    setResults(null);

    try {
      // Simulate progress for better UX
      const progressSteps = [20, 40, 60, 80, 100];
      for (let i = 0; i < progressSteps.length; i++) {
        setProgress(progressSteps[i]);
        await new Promise(resolve => setTimeout(resolve, 300));
      }

      const securityResults = await performSecurityChecks(url);
      setResults(securityResults);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to scan the website. Please try again.';
      setError(errorMessage);
      console.error('Scan error:', err);
    } finally {
      setLoading(false);
      setProgress(0);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleScan();
    }
  };

  const getOverallScore = (results: SecurityResult): number => {
    if (!results) return 0;
    
    const checks = [
      results.httpsCheck,
      results.headersCheck,
      results.cookieCheck,
      results.formCheck,
      results.linkCheck
    ];
    
    const passedChecks = checks.filter(check => check.status === 'pass').length;
    return Math.round((passedChecks / checks.length) * 100);
  };

  const getScoreColor = (score: number): string => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Shield className="w-12 h-12 text-blue-600 mr-3" />
            <h1 className="text-4xl font-bold text-gray-800">Web Security Checker</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A beginner-friendly tool to analyze basic web security features. 
            Perfect for learning and understanding fundamental security concepts.
          </p>
          <div className="mt-4 inline-flex items-center px-4 py-2 bg-blue-100 rounded-full">
            <Info className="w-4 h-4 text-blue-600 mr-2" />
            <span className="text-blue-700 text-sm font-medium">Built for Learning & Portfolio</span>
          </div>
        </div>

        {/* URL Input */}
        <div className="max-w-2xl mx-auto mb-8">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <label htmlFor="url" className="block text-lg font-semibold text-gray-700 mb-3">
              Enter Website URL
            </label>
            <div className="flex gap-3">
              <input
                type="text"
                id="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="https://example.com"
                className="flex-1 px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-colors text-lg"
                disabled={loading}
              />
              <button
                onClick={handleScan}
                disabled={loading}
                className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-200 transition-colors font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <Loader className="w-5 h-5 animate-spin" />
                ) : (
                  'Scan'
                )}
              </button>
            </div>
            {error && (
              <p className="mt-3 text-red-600 flex items-center">
                <XCircle className="w-4 h-4 mr-2" />
                {error}
              </p>
            )}
          </div>
        </div>

        {/* Progress Bar */}
        {loading && (
          <div className="max-w-2xl mx-auto mb-8">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex items-center mb-3">
                <Loader className="w-5 h-5 animate-spin text-blue-600 mr-2" />
                <span className="text-gray-700 font-medium">Scanning website...</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-blue-600 h-3 rounded-full transition-all duration-300 ease-out"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
              <p className="text-sm text-gray-600 mt-2">{progress}% complete</p>
            </div>
          </div>
        )}

        {/* Results */}
        {results && !loading && (
          <div className="max-w-6xl mx-auto">
            {/* Overall Score */}
            <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
              <div className="text-center">
                <h2 className="text-2xl font-bold text-gray-800 mb-4">Security Score</h2>
                <div className={`text-6xl font-bold ${getScoreColor(getOverallScore(results))} mb-2`}>
                  {getOverallScore(results)}%
                </div>
                <p className="text-gray-600">
                  {getOverallScore(results) >= 80 ? 'Excellent security posture!' :
                   getOverallScore(results) >= 60 ? 'Good security, room for improvement' :
                   'Security needs attention'}
                </p>
              </div>
            </div>

            {/* Security Check Results */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              <ResultCard check={results.httpsCheck} />
              <ResultCard check={results.headersCheck} />
              <ResultCard check={results.cookieCheck} />
              <ResultCard check={results.formCheck} />
              <ResultCard check={results.linkCheck} />
            </div>

            {/* Educational Panel */}
            <EducationalPanel />
          </div>
        )}

        {/* About Section */}
        <div className="max-w-4xl mx-auto mt-16 bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">About This Project</h2>
          <div className="prose prose-gray max-w-none">
            <p className="text-gray-600 mb-4">
              This Web Security Checker is designed as an educational tool to help developers and students 
              understand basic web security concepts. It performs client-side analysis of websites to identify 
              common security features and potential improvements.
            </p>
            <div className="grid md:grid-cols-2 gap-6 mt-6">
              <div>
                <h3 className="font-semibold text-gray-800 mb-2">What it checks:</h3>
                <ul className="text-gray-600 space-y-1">
                  <li>• HTTPS encryption</li>
                  <li>• Security headers</li>
                  <li>• Cookie security</li>
                  <li>• Form protection</li>
                  <li>• External link analysis</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800 mb-2">Perfect for:</h3>
                <ul className="text-gray-600 space-y-1">
                  <li>• Learning web security basics</li>
                  <li>• Portfolio projects</li>
                  <li>• Understanding security concepts</li>
                  <li>• Student demonstrations</li>
                  <li>• Educational purposes</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityChecker;