export interface SecurityCheck {
  title: string;
  description: string;
  status: 'pass' | 'warning' | 'fail';
  explanation: string;
  recommendation?: string;
  details?: string[];
}

export interface SecurityResult {
  url: string;
  scannedAt: string;
  httpsCheck: SecurityCheck;
  headersCheck: SecurityCheck;
  cookieCheck: SecurityCheck;
  formCheck: SecurityCheck;
  linkCheck: SecurityCheck;
  sslCheck: SecurityCheck;
}