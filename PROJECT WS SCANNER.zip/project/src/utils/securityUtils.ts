import { SecurityResult } from '../types/security';

const API_BASE_URL = 'http://localhost:8000';

export const performSecurityChecks = async (url: string): Promise<SecurityResult> => {
  try {
    // First check if backend is available
    const healthResponse = await fetch(`${API_BASE_URL}/health`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!healthResponse.ok) {
      throw new Error('Backend server is not responding. Please make sure the Python backend is running on port 8000.');
    }

    // Perform the actual scan
    const response = await fetch(`${API_BASE_URL}/scan`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ url }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || `HTTP ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    
    // Transform the API response to match our frontend interface
    return {
      url: data.url,
      scannedAt: data.scanned_at,
      httpsCheck: data.https_check,
      headersCheck: data.headers_check,
      cookieCheck: data.cookie_check,
      formCheck: data.form_check,
      linkCheck: data.link_check,
      sslCheck: data.ssl_check
    };
  } catch (error) {
    // If the backend is not available, show a helpful error
    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new Error('Cannot connect to backend server. Please start the Python backend by running: python backend/run.py');
    }
    throw error;
  }
};