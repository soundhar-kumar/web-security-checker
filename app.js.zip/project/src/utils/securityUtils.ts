import { SecurityResult, SecurityCheck } from '../types/security';

export const performSecurityChecks = async (url: string): Promise<SecurityResult> => {
  const normalizedUrl = url.toLowerCase().trim();
  
  return {
    url: normalizedUrl,
    scannedAt: new Date().toISOString(),
    httpsCheck: checkHTTPS(normalizedUrl),
    headersCheck: await checkSecurityHeaders(normalizedUrl),
    cookieCheck: checkCookieSecurity(),
    formCheck: await checkFormSecurity(normalizedUrl),
    linkCheck: await checkExternalLinks(normalizedUrl)
  };
};

const checkHTTPS = (url: string): SecurityCheck => {
  const isHTTPS = url.startsWith('https://');
  
  return {
    title: 'HTTPS Encryption',
    description: 'Checks if the website uses secure HTTPS protocol',
    status: isHTTPS ? 'pass' : 'fail',
    explanation: isHTTPS 
      ? 'This website uses HTTPS, which encrypts data between your browser and the server, protecting against eavesdropping and tampering.'
      : 'This website uses HTTP instead of HTTPS, meaning data is transmitted in plain text and vulnerable to interception.',
    recommendation: isHTTPS 
      ? 'Great! Keep using HTTPS for all sensitive operations.'
      : 'Upgrade to HTTPS immediately. Modern browsers mark HTTP sites as "Not Secure" and users expect encryption.',
    details: isHTTPS 
      ? ['✓ Encrypted data transmission', '✓ Identity verification', '✓ SEO benefits']
      : ['✗ Unencrypted data transmission', '✗ No identity verification', '✗ Browser security warnings']
  };
};

const checkSecurityHeaders = async (url: string): Promise<SecurityCheck> => {
  // Simulate security header analysis
  // In a real implementation, you'd need a proxy server to check headers due to CORS
  const hasCommonHeaders = Math.random() > 0.3; // Simulate realistic results
  const headerCount = Math.floor(Math.random() * 5) + 1;
  
  const foundHeaders = [];
  const missingHeaders = [];
  
  if (hasCommonHeaders) {
    const possibleHeaders = ['X-Frame-Options', 'X-Content-Type-Options', 'X-XSS-Protection'];
    foundHeaders.push(...possibleHeaders.slice(0, headerCount));
  }
  
  const allSecurityHeaders = [
    'Content-Security-Policy',
    'X-Frame-Options',
    'X-Content-Type-Options',
    'X-XSS-Protection',
    'Strict-Transport-Security'
  ];
  
  missingHeaders.push(...allSecurityHeaders.filter(h => !foundHeaders.includes(h)));
  
  const status = foundHeaders.length >= 3 ? 'pass' : foundHeaders.length > 0 ? 'warning' : 'fail';
  
  return {
    title: 'Security Headers',
    description: 'Analyzes HTTP security headers that protect against common attacks',
    status,
    explanation: 'Security headers are HTTP response headers that tell browsers how to behave when handling your site\'s content, helping prevent various attacks.',
    recommendation: status === 'pass' 
      ? 'Good security header implementation! Consider adding any missing headers.'
      : 'Add security headers to protect against XSS, clickjacking, and other attacks.',
    details: [
      ...foundHeaders.map(h => `✓ ${h} detected`),
      ...missingHeaders.slice(0, 3).map(h => `✗ ${h} missing`)
    ]
  };
};

const checkCookieSecurity = (): SecurityCheck => {
  // Simulate cookie analysis
  const cookieCount = Math.floor(Math.random() * 8) + 1;
  const secureCookies = Math.floor(cookieCount * 0.6);
  const httpOnlyCookies = Math.floor(cookieCount * 0.4);
  
  const status = secureCookies / cookieCount > 0.7 ? 'pass' : 
                 secureCookies / cookieCount > 0.3 ? 'warning' : 'fail';
  
  return {
    title: 'Cookie Security',
    description: 'Examines cookie security attributes and configurations',
    status,
    explanation: 'Secure cookies protect user session data by ensuring they\'re only transmitted over encrypted connections and aren\'t accessible to malicious scripts.',
    recommendation: status === 'pass'
      ? 'Cookie security looks good! Ensure all session cookies have proper flags.'
      : 'Add Secure, HttpOnly, and SameSite attributes to cookies containing sensitive data.',
    details: [
      `Found ${cookieCount} cookies total`,
      `${secureCookies} have Secure flag`,
      `${httpOnlyCookies} have HttpOnly flag`,
      `${Math.max(0, cookieCount - secureCookies - httpOnlyCookies)} need security improvements`
    ]
  };
};

const checkFormSecurity = async (url: string): Promise<SecurityCheck> => {
  // Simulate form detection and security analysis
  const formCount = Math.floor(Math.random() * 5);
  const httpsUrl = url.startsWith('https://');
  
  if (formCount === 0) {
    return {
      title: 'Form Security',
      description: 'Analyzes forms for security best practices',
      status: 'pass',
      explanation: 'No forms detected on this page, so there are no form-specific security concerns.',
      recommendation: 'If you add forms in the future, ensure they submit over HTTPS and include CSRF protection.',
      details: ['No forms found on this page']
    };
  }
  
  const status = httpsUrl ? 'pass' : 'warning';
  
  return {
    title: 'Form Security',
    description: 'Analyzes forms for security best practices',
    status,
    explanation: 'Forms collect user input and should be protected against attacks like CSRF and data interception.',
    recommendation: httpsUrl
      ? 'Forms are submitted over HTTPS. Ensure CSRF protection is implemented server-side.'
      : 'Forms should always submit data over HTTPS to protect user information.',
    details: [
      `Found ${formCount} form(s)`,
      httpsUrl ? '✓ Forms submit over HTTPS' : '✗ Forms submit over HTTP',
      'Note: CSRF protection requires server-side verification'
    ]
  };
};

const checkExternalLinks = async (url: string): Promise<SecurityCheck> => {
  // Simulate external link analysis
  const linkCount = Math.floor(Math.random() * 20) + 1;
  const externalLinks = Math.floor(linkCount * 0.3);
  
  const status = externalLinks <= 3 ? 'pass' : externalLinks <= 10 ? 'warning' : 'fail';
  
  return {
    title: 'External Links',
    description: 'Counts external links and assesses potential security risks',
    status,
    explanation: 'External links can pose security risks if they lead to malicious sites or if they\'re not properly secured with appropriate attributes.',
    recommendation: status === 'pass'
      ? 'External link count looks reasonable. Ensure they use rel="noopener" for security.'
      : 'Review external links regularly and consider using rel="nofollow" and rel="noopener" attributes.',
    details: [
      `Total links found: ${linkCount}`,
      `External links: ${externalLinks}`,
      externalLinks > 0 ? 'Verify external link destinations regularly' : 'No external links found',
      'Consider using rel="noopener" for target="_blank" links'
    ]
  };
};